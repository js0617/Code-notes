const envList = [{ "envId": "cloud1-5grrgzzcc17c80d0", "alias": "cloud1" }, { "envId": "project-one-8g7drnus4e063df3", "alias": "project-one" }]
const isMac = false
module.exports = {
    envList,
    isMac
}