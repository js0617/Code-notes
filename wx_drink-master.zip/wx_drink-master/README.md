#### **项目名称：茶饮扫码点单+后台订单的实时响应 微信小程序**

 **技术栈：**小程序原生开发框架 + 云开发后台

 **项目描述：**

1、通过微信小程序，扫描不同桌号的二维码跳，识别桌号转到商品列表页;

2、商品的模糊搜索功能，购物车功能，实现商品的购买，下单;

3、微信在线支付，提交订单的同时，后台会实时响应最新的订单消息并展示到后台界面;

4、 用户注册/登录功能，可以查看历史账单，进行留言评价来增加用户粘性。



附：餐厅桌号（依次为一号桌 、二号卓、三号卓）



https://raw.githubusercontent.com/ylsirs/wx_drink/master/miniprogram/images/QR%20code/one.png

https://github.com/ylsirs/wx_drink/blob/master/miniprogram/images/QR%20code/two.png

https://github.com/ylsirs/wx_drink/blob/master/miniprogram/images/QR%20code/three.png
